# LoteAutos2017
Proyecto desarrollado para la Materia de Desarrollo de Aplicaciones en la Universidad Tecnologica de Hermosillo


El siguiente proyecto utiliza el Framework de aforgenet para activar la web cam y lograr capturar la imagen
el framework lo puedes descargar de la pagina oficial:
http://www.aforgenet.com/framework/downloads.html

el proyecto requiere la referenca a las librerias:
  AForge.Video.DirectShow;
  LoteAutos2017.Comun;
  
  Lebrerias y mas (AFORGE)
